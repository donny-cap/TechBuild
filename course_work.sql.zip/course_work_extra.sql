
--
-- Indexes for dumped tables
--

--
-- Indexes for table `delivered_materials`
--
ALTER TABLE `delivered_materials`
  ADD PRIMARY KEY (`number`),
  ADD UNIQUE KEY `name_of_material_UNIQUE` (`name`);

--
-- Indexes for table `finished_objects`
--
ALTER TABLE `finished_objects`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`number`),
  ADD UNIQUE KEY `name_of_material_UNIQUE` (`name`);

--
-- Indexes for table `materials_to_delivery`
--
ALTER TABLE `materials_to_delivery`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `objects_constructing`
--
ALTER TABLE `objects_constructing`
  ADD PRIMARY KEY (`number`),
  ADD UNIQUE KEY `Name_of_areas_UNIQUE` (`objects`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`account_type`,`firstname`,`lastname`,`login`,`password`),
  ADD UNIQUE KEY `firstname_UNIQUE` (`firstname`),
  ADD UNIQUE KEY `lastname_UNIQUE` (`lastname`),
  ADD UNIQUE KEY `login_UNIQUE` (`login`),
  ADD UNIQUE KEY `password_UNIQUE` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delivered_materials`
--
ALTER TABLE `delivered_materials`
  MODIFY `number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `finished_objects`
--
ALTER TABLE `finished_objects`
  MODIFY `number` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `materials`
--
ALTER TABLE `materials`
  MODIFY `number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `materials_to_delivery`
--
ALTER TABLE `materials_to_delivery`
  MODIFY `number` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `objects_constructing`
--
ALTER TABLE `objects_constructing`
  MODIFY `number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
