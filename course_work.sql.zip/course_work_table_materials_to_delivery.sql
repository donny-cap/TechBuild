
-- --------------------------------------------------------

--
-- Table structure for table `materials_to_delivery`
--

CREATE TABLE `materials_to_delivery` (
  `number` int(10) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  `manufacturer` varchar(55) DEFAULT NULL,
  `quantity` int(10) DEFAULT NULL,
  `cost` int(10) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `materials_to_delivery`
--

INSERT INTO `materials_to_delivery` (`number`, `name`, `manufacturer`, `quantity`, `cost`, `date`) VALUES
(1, 'Rail (0.03*0.05*6)', 'Forest Russia', 10, 230, '2021-12-20');
