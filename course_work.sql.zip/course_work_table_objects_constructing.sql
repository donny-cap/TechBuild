
-- --------------------------------------------------------

--
-- Table structure for table `objects_constructing`
--

CREATE TABLE `objects_constructing` (
  `number` int(11) NOT NULL,
  `objects` varchar(40) NOT NULL,
  `company` varchar(255) NOT NULL,
  `square (m2)` int(10) UNSIGNED NOT NULL,
  `address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `objects_constructing`
--

INSERT INTO `objects_constructing` (`number`, `objects`, `company`, `square (m2)`, `address`) VALUES
(1, 'EL Klasi', 'CupStroy', 2560, 'str. Isakeev 2'),
(3, 'Evergreen', 'EliteHouse', 1710, 'str. Erkindik 52'),
(4, 'Imperial', 'Ihlas', 1260, 'Sverdlovsky district'),
(5, 'Keremet', 'EmarkStroy', 2890, 'str. Lev Tolstoy 112/5'),
(6, 'Kok-Jar deLuxe', 'BishkekKurulush', 3880, 'Oktyabrsky district'),
(7, 'Nur-Ordo', 'CupStroy', 3970, 'str. Isanova 48/6'),
(8, 'Zalkar', 'EmarkStroy', 3465, 'str. Kulatov 66'),
(9, 'Eles', 'TSgroup', 2468, 'str. Mederova 103'),
(10, 'Karpinka', 'CupStroy', 2751, 'str. Karasaeva 89'),
(11, 'AC\"Tyhiy Ugolok2\"', 'EmarkStroy', 1275, 'str. Bokonbai 97'),
(12, 'AH \"Ihsan\"', 'Ihlas', 3698, 'str. Gogolya 57'),
(13, 'Club house \"Romance\"', 'CupStroy', 1972, 'str. Frunze');
