
-- --------------------------------------------------------

--
-- Table structure for table `delivered_materials`
--

CREATE TABLE `delivered_materials` (
  `number` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `weight (kg)` int(10) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivered_materials`
--

INSERT INTO `delivered_materials` (`number`, `name`, `manufacturer`, `quantity`, `weight (kg)`, `date`) VALUES
(1, 'Putty (Glad)', 'Kraft', '50', 25, '2020-01-02'),
(2, 'Gypsum board K (12.5mm)', 'Knauf', '100', 25, '2020-01-03'),
(3, 'Gypsum board K (9.5mm)', 'Knauf', '75', 20, '2020-09-28'),
(4, 'Сement (M500)', 'Kant Zavod', '55', 50, '2020-01-01');
