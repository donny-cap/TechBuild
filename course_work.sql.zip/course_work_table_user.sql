
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `account_type` varchar(40) NOT NULL,
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`account_type`, `firstname`, `lastname`, `login`, `password`) VALUES
('Builder', '-', '-', 'build', '1234'),
('Builder', 'Cholpon', 'Sultanova', 'Chopa123', '1234chopa'),
('Builder', 'Daniyar', 'Moldobasarov', 'Donny123', '1234donny'),
('Supplier', '', '', 'supp', '12345'),
('Supplier', 'Azamat', 'Satybaldiev', 'Aza123', '1234aza'),
('Supplier', 'Donny', 'Moslem', 'Donny', '221101');
