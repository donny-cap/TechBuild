
-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

CREATE TABLE `materials` (
  `number` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `manufacturer` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `weight (kg)` int(10) NOT NULL,
  `cost` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`number`, `name`, `manufacturer`, `type`, `quantity`, `weight (kg)`, `cost`) VALUES
(1, 'Balk (0.10*0.10*6)', 'Forest Russia', 'lumber', 100, 10, 1530),
(2, 'Edged board (0.03*0.06*6)', 'Forest Russia', 'lumber', 78, 5, 275),
(3, 'Edged board (0.04*0.10*6)', 'Forest Russia', 'lumber', 50, 5, 612),
(4, 'Edged board (0.04*0.20*6)', 'Forest Russia', 'lumber', 50, 6, 1224),
(5, 'Edged board (0.05*0.18*6)', 'Forest Russia', 'lumber', 80, 7, 1377),
(6, 'Rail (0.03*0.05*6)', 'Forest Russia', 'lumber', 90, 2, 230),
(7, 'Rail (0.04*0.05*6)', 'Forest Russia', 'lumber', 100, 3, 300),
(8, 'Rail (0.05*0.05*6)', 'Forest Russia', 'lumber', 100, 4, 380),
(9, 'Gypsum board K (12.5mm)', 'Knauf', 'drywall', 80, 25, 460),
(10, 'Gypsum board K (9.5mm)', 'Knauf', 'drywall', 100, 22, 400),
(11, 'Gypsum board G (12.5mm)', 'Gifas', 'drywall', 100, 25, 460),
(12, 'Gypsum board G (9.5mm)', 'Gifas', 'drywall', 100, 22, 380),
(13, 'penoplex', 'Teppa Wood Comp', 'Polymaterials', 10, 0, 1000),
(14, 'flitch', 'AQUAdom', 'Polymaterials', 10, 0, 1000),
(15, 'cement', 'AQUAdom', 'Cementing materials', 20, 0, 5300),
(16, 'gypsum', 'Buzzi', 'Cementing materials', 20, 0, 5300),
(17, 'lime', 'Buzzi', 'Cementing materials', 20, 0, 5300),
(19, 'fitting', 'AQUAdom', 'Metal products', 100, 0, 15000),
(20, 'grid(steel)', 'AQUAdom', 'Metal products', 100, 0, 15000),
(21, 'sand', 'Stroymag', 'Nonmetallic materials', 100, 0, 26000),
(22, 'steel bar', 'AQUAdom', 'Metal products', 100, 0, 15000),
(23, 'clay', 'Stroymag', 'Nonmetallic materials', 100, 0, 26000),
(24, 'pipe', 'AQUAdom', 'Metal products', 100, 0, 15000),
(25, 'rubble', 'Stroymag', 'Nonmetallic materials', 100, 0, 26000),
(26, 'styrofoam', 'ALABAMACom', 'repair materials', 200, 0, 32400),
(27, 'brick', 'Bulldozzer Group', 'Wall materials', 10000, 0, 70000);
