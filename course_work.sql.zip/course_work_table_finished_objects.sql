
-- --------------------------------------------------------

--
-- Table structure for table `finished_objects`
--

CREATE TABLE `finished_objects` (
  `number` int(10) NOT NULL,
  `objects` varchar(40) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(45) NOT NULL,
  `square (m2)` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `finished_objects`
--

INSERT INTO `finished_objects` (`number`, `objects`, `company`, `address`, `square (m2)`, `date`) VALUES
(1, 'Sofia', 'EliteHouse', 'str. Tokombaeva 27/4', 1900, '2018-11-01'),
(2, 'Maximum Plus', 'EliteHouse', 'str. Turusbekova 109/1', 4200, '2018-09-11'),
(3, 'South Park', 'EliteHouse', 'str. Sayakbai Karalaev 40/4', 3467, '2019-09-05'),
(4, 'Ala Too', 'EliteHouse', 'str. Isakeev 2', 8900, '2019-02-19'),
(5, 'Italien Quarter', 'EliteHouse', 'str. S.Bator', 11500, '2019-05-15'),
(6, 'Asanbai Ordo', 'EliteHouse', 'str. Aaly Tokombaev', 15800, '2021-03-28'),
(7, 'New York City', 'EliteHouse', 'str S.Batora', 2872, '2020-05-22'),
(8, 'Aleksandriya', 'EliteHouse', 'str. Togolok Moldo', 2551, '2020-09-18'),
(9, 'El Classico', 'EliteHouse', 'str. Isanova', 4500, '2021-02-12'),
(15, '\"+objects+\"', '\"+company+\"', '\"+address+\"', 0, '0000-00-00'),
(16, 'objects', 'company', 'address', 9999, '2021-12-19');
